<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.6" name="fg_sky" tilewidth="64" tileheight="64" tilecount="527" columns="31">
 <image source="../graphics/sky/fg_sky.png" width="1984" height="1088"/>
</tileset>
