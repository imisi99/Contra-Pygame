<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.4" name="Subway_tiles_x4" tilewidth="64" tileheight="64" tilecount="625" columns="25">
 <image source="../graphics/tilesets/Subway_tiles.png" width="1600" height="1600"/>
</tileset>
