<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.6" name="Platforms" tilewidth="192" tileheight="56" tilecount="2" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="192" height="56" source="../graphics/platforms/p1.png"/>
 </tile>
 <tile id="1">
  <image width="94" height="56" source="../graphics/platforms/p2.png"/>
 </tile>
</tileset>
