<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.4" name="wall_subway" tilewidth="64" tileheight="64" tilecount="1505" columns="35">
 <image source="../graphics/tilesets/wall_subway.png" width="2240" height="2784"/>
</tileset>
