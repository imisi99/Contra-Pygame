<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.6" name="tiles_out" tilewidth="64" tileheight="64" tilecount="325" columns="13">
 <image source="../graphics/tilesets/tiles_out.png" width="832" height="1600"/>
</tileset>
